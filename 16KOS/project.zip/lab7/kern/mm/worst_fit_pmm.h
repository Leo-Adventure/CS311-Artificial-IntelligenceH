#ifndef __KERN_MM_WORST_FIT_PMM_H__
#define  __KERN_MM_WORST_FIT_PMM_H__
#include <pmm.h>
#include <stdio.h>

extern const struct pmm_manager worst_fit_pmm_manager;

#endif /* ! __KERN_MM_WORST_FIT_PMM_H__ */

